# Assembly-Programs-basics-

This are some basic Assembly Operations done on Single and Double Digit numbers also Some basic string operations too.
To read the file, open it on the notepad or any other text editor.
The basic terminal Commands fot the assembly program are written in Commands(1) file.
